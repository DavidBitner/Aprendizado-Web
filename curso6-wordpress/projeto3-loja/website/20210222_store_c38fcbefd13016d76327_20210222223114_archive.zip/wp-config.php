<?php

/**

 * The base configuration for WordPress

 *

 * The wp-config.php creation script uses this file during the

 * installation. You don't have to use the web site, you can

 * copy this file to "wp-config.php" and fill in the values.

 *

 * This file contains the following configurations:

 *

 * * MySQL settings

 * * Secret keys

 * * Database table prefix

 * * ABSPATH

 *

 * @link https://wordpress.org/support/article/editing-wp-config-php/

 *

 * @package WordPress

 */


// ** MySQL settings - You can get this info from your web host ** //

/** The name of the database for WordPress */

define( 'DB_NAME', '' );


/** MySQL database username */

define( 'DB_USER', '' );


/** MySQL database password */

define( 'DB_PASSWORD', '' );


/** MySQL hostname */

define( 'DB_HOST', '' );


/** Database Charset to use in creating database tables. */

define( 'DB_CHARSET', 'utf8mb4' );


/** The Database Collate type. Don't change this if in doubt. */

define( 'DB_COLLATE', '' );


/**#@+

 * Authentication Unique Keys and Salts.

 *

 * Change these to different unique phrases!

 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}

 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.

 *

 * @since 2.6.0

 */

define( 'AUTH_KEY',         '[-X,Pu0ZpQDaPKG.w[C v_gaaJ%tL7WxbB^7XD@8BM>QfGRa]5`EiXQRy|~9v6m$' );

define( 'SECURE_AUTH_KEY',  'qY6X6/x]P6}HPm6hu&g+T}sQA,nU?}Nw;MXdv <gAGhR?LK t9]?bFrH#e-7-sH!' );

define( 'LOGGED_IN_KEY',    ':s-J}CQiKStI7Xb2 X|NsH`Fb6p$A PmR:H4H#9e]RhjNX2<-Cb$C4f(1>^ucd~M' );

define( 'NONCE_KEY',        'B<D6mrCsnShcep/01f!(Cj|LobD]lYj7~WZ:?ED]tN0jyQ(sHC Jw=eFDpjhIFwh' );

define( 'AUTH_SALT',        'x?Z[m@[zf5RXc_`/vZs.{-@[=ND{gry>1~Org-3,,0*cY!{TjJO&4Jb-Y=|OU@o+' );

define( 'SECURE_AUTH_SALT', 'G_4H_R(?4]vv7Ahe7#~Op~siS*^yb4 cpVhrfmRlooitIJPbbhXkL`{GW*5Pnd]S' );

define( 'LOGGED_IN_SALT',   '=TUiB1l5|l#Xe1&auiJUW!eh$YIY8Oso7)M3J(OV5e kdA a2} -QNx Tq</)L&X' );

define( 'NONCE_SALT',       'oqR2],r5-uhgl3yf|7/(R,#)7t| 5G+p$A%_]JIALjPo%%>SGBTae,P>B#AOQ7B$' );


/**#@-*/


/**

 * WordPress Database Table prefix.

 *

 * You can have multiple installations in one database if you give each

 * a unique prefix. Only numbers, letters, and underscores please!

 */

$table_prefix = 'wp_';


/**

 * For developers: WordPress debugging mode.

 *

 * Change this to true to enable the display of notices during development.

 * It is strongly recommended that plugin and theme developers use WP_DEBUG

 * in their development environments.

 *

 * For information on other constants that can be used for debugging,

 * visit the documentation.

 *

 * @link https://wordpress.org/support/article/debugging-in-wordpress/

 */

define( 'WP_DEBUG', false );


/* That's all, stop editing! Happy publishing. */


/** Absolute path to the WordPress directory. */

if ( ! defined( 'ABSPATH' ) ) {

	define( 'ABSPATH', __DIR__ . '/' );

}


/** Sets up WordPress vars and included files. */

require_once ABSPATH . 'wp-settings.php';

